set termout off

spool source/apex/f427.sql

apex export 427

spool source/apex/f209021.sql

apex export 209021

spool off

exit